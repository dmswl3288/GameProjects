﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonManager : MonoBehaviour {

    // Use this for initialization
    // LastScene에서 이전 스크립트 모두 초기화
    void Awake()
    {
        Camera_Move.CameraMoveSwitch = false;
        Camera_Move.Cube_Creating = false;
        Camera_Move.isGameEnd = false;

        Camera_Move._score = 0;
      //  Camera_Move._totalScore = 0;

        TitleCollision._displayTitle = false;

        SecondGroundCol._isGroundCount = 0;

    }
    void Start () {

    }
	
	// Update is called once per frame
	void Update () {
		
	}

    // 게임 재시작하는 함수
    public void OnClickedReStartButton()
    {

        SceneManager.LoadScene("TopBlock");
    }

    // 타이틀 화면으로 가는 함수
    public void OnClickedGoHomeButton()
    {
        SceneManager.LoadScene("TopBlockTitle");
    }

    // 어플리케이션 종료 함수
    public void OnClickedExitButton()
    {
        Application.Quit();
    }
}
