﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Camera_Move : MonoBehaviour {

    public GUISkin mySkin;

    float _y;
    static public bool CameraMoveSwitch = false;
    static public bool Cube_Creating = false;
    static public bool isGameEnd = false;

    static public int _score = 0;
    static public int _totalScore = 0;

    // Use this for initialization
    void Start () {
        _y = transform.position.y;
    }

    // Update is called once per frame
    void Update () {

            if (CameraMoveSwitch)
            {
                // 땅에 2번이상 닿은 경우
                if (transform.position.y < _y + 1 && SecondGroundCol._isGroundCount < 2) 
                {
                    transform.position += new Vector3(0, Time.deltaTime, 0); // camera이동 정지

                }
            else
                {
                    _y = transform.position.y;
                    CameraMoveSwitch = false;
                    Cube_Creating = true;
                }        
            }
        
    }

    // 코루틴 함수
    IEnumerator NextLastScene()
    {
        // 2초 대기 후 라스트 씬으로 이동
        yield return new WaitForSeconds(2.0f);
        SceneManager.LoadScene("TopBlockLastScene");
    }

    private void OnGUI()
    {
        GUI.skin = mySkin;

        int sw = Screen.width;
        int sh = Screen.height;

        GUI.Label(new Rect(5, 5, sw / 2, sh / 4), "Score : " + _score, "Score");

        if (SecondGroundCol._isGroundCount >= 2)
        {
            GUI.Label(new Rect(0,sh/2,sw,sh/4),"The End","TheEnd");
            isGameEnd = true;   // 게임 종료 
            // 코루틴 시작
            StartCoroutine(NextLastScene());
        }
    }
}
