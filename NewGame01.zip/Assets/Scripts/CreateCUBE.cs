﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CreateCUBE : MonoBehaviour {

    private AudioSource audio;
    public AudioClip jumpSound;

    //public Sprite nextSprite;
    // private SpriteRenderer spriteRenderer;
    public Sprite[] sprites = new Sprite[9];
    private SpriteRenderer spriteRenderer;

    int i = 0;

    // Instantiate할 오브젝트 정의
    public GameObject cube;
    GameObject _cube;
    int y = 1;

	// Use this for initialization
	void Start () {

        this.audio = this.gameObject.AddComponent<AudioSource>();
        this.audio.clip = this.jumpSound;
        this.audio.loop = false;

        _cube = Instantiate(cube, new Vector3(0, y, -1), Quaternion.identity); // 큐브 인스턴스화
        _cube.AddComponent<Cube_Move>();
        _cube.AddComponent<isCollision>();

        spriteRenderer = _cube.GetComponent<SpriteRenderer>();
        spriteRenderer.sprite = sprites[i];
	}
	
	// Update is called once per frame
	void Update () {

        if (Camera_Move.isGameEnd == false) // 게임이 끝나지 않은 경우
        {

            if (Input.anyKeyDown)
            {
                _cube.transform.position += new Vector3(0, 1, 0);  // 위로 점프 후 낙하
                _cube.AddComponent<Rigidbody2D>().angularDrag = 0.05f;

                if (SoundManager.isOnSound == true)
                {
                    this.audio.Play();
                }
                i++;   // 배열 증가
                if (i >= 9)
                {
                    i = 0;
                }
            }


            if (Camera_Move.Cube_Creating)
            {
                // score 증가
                Camera_Move._score += 5;
                Camera_Move._totalScore = Camera_Move._score; // 최종점수 저장

                y++;
                _cube = Instantiate(cube, new Vector3(0, y, -1), Quaternion.identity);
                _cube.GetComponent<SpriteRenderer>().sprite = sprites[i];  // sprite변경
                _cube.AddComponent<Cube_Move>();
                _cube.AddComponent<isCollision>();
                Camera_Move.Cube_Creating = false;

            }
        }

    }
}
