﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cube_Move : MonoBehaviour {

    public float _direction = 2;
    

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {

        if (transform.position.x > 2 || transform.position.x < -2)
        {
            _direction = -_direction;
        }
        transform.position += new Vector3(Time.deltaTime * _direction, 0, 0);

        if(Input.anyKeyDown)
        {
            _direction = 0;  // 누른 순간 이동 정지
        }
    }
}
