﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FadeInOut : MonoBehaviour { // 아침에서 밤으로 배경 밝기 변경하는 스크립트

    double red;
    double green;
    double blue;

	// Use this for initialization
	void Start () {

        red = 255;
        green = 255;
        blue = 255;
	}
	
	// Update is called once per frame
	void Update () {

        if (Camera_Move._score == 40)   // 40점에 도달하면 
        {
            if (red > 125 && green > 125 && blue > 125)  // 255에서 125까지 어두워짐
            {
                red -= Time.deltaTime * 50;
                green -= Time.deltaTime * 50;
                blue -= Time.deltaTime * 50;
                this.gameObject.GetComponent<Image>().color = new Color((float)red / 255, (float)green / 255, (float)blue / 255);
            }
        }
        if(Camera_Move._score == 60)   // 60에 도달하면 다시 밝아짐
        {
            red += Time.deltaTime * 50;
            green += Time.deltaTime * 50;
            blue += Time.deltaTime * 50;
            this.gameObject.GetComponent<Image>().color = new Color((float)red / 255, (float)green / 255, (float)blue / 255);
        }
	}

}
