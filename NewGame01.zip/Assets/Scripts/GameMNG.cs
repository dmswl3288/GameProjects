﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameMNG : MonoBehaviour {

    public GameObject _popUpCanvas;
    public GameObject _popUpPanel;
    GameObject _popUp;

    // 백버튼 누른 횟수
    int _exitCount = 0;
    int _popUpApprearCount = 0;

    // Use this for initialization
    void Start () {

        // 화면 비율 조정
        int i_width = Screen.width;
        int i_height = Screen.height;
        Screen.SetResolution(i_width, i_height, true);

    }
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKeyUp(KeyCode.Escape))
        {
            _exitCount++;
            _popUpApprearCount = 1;
            if (!IsInvoking("disable_DoubleClick"))
                Invoke("disable_DoubleClick", 0.3f);  //0.3초안에 두번 클릭안한 경우 호출

            
        }
        if (_exitCount == 2)
        {
            CancelInvoke("disable_DoubleClick");
            //Application.Quit();
            // panel Popup 인스턴스화  팝업창 띄우기
            if (_popUpApprearCount == 1) // 창 한번만 띄우도록
            {
                _popUp = Instantiate(_popUpPanel, new Vector3(0, 1, -1), Quaternion.identity);

                _popUp.transform.SetParent(_popUpCanvas.transform, false);

                _popUp.transform.Find("XButton").GetComponent<UnityEngine.UI.Button >().onClick.AddListener(delegate { XButtonClicked(); });
                _popUp.transform.Find("YesButton").GetComponent<UnityEngine.UI.Button>().onClick.AddListener(delegate { YesButtonClicked(); });
                _popUp.transform.Find("NoButton").GetComponent<UnityEngine.UI.Button>().onClick.AddListener(delegate { NoButtonClicked(); });

                _popUpApprearCount = 0;
                _exitCount = 0;
            }
        }

    }
    // 빨리 두번 누르지 않으면 다시 카운드 0
    void disable_DoubleClick()
    {
        _exitCount = 0;
    }

    void XButtonClicked()
    {
        // 팝업창 destroy
        Destroy(_popUp);
    }

    void YesButtonClicked()
    {
        Application.Quit();
    }

    void NoButtonClicked()
    {
        // 팝업창 destroy   X버튼과 동일
        Destroy(_popUp);
    }
}
