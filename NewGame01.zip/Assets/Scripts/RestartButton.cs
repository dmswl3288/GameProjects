﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RestartButton : MonoBehaviour {

    private float red;
    private float green;
    private float blue;

	// Use this for initialization
	void Start () {

        red = 255;
        green = 255;
        blue = 255;

        InvokeRepeating("ChangeColor", 1, 0.6f);
	}
	
	// Update is called once per frame
	void Update () {

        this.gameObject.GetComponent<Image>().color = new Color(red / 255, green / 255, blue / 255);
    }

    void ChangeColor()
    {
        if (red == 255)
        {
            red = 120;
            green = 120;
            blue = 120;
        }
        else
        {
            red = 255;
            green = 255;
            blue = 255;
        }
    }
}
