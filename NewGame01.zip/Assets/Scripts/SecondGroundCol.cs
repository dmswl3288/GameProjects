﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SecondGroundCol : MonoBehaviour {

    static public int _isGroundCount = 0;

    private AudioSource endAudio;
    public AudioClip theEndSound;

	// Use this for initialization
	void Start () {
        this.endAudio = this.gameObject.AddComponent<AudioSource>();
        this.endAudio.clip = this.theEndSound;
        this.endAudio.loop = false;
        this.endAudio.volume = 0.15f;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Cube")
        {
            _isGroundCount++;   //_isGroundCount = 1
        }

        if(_isGroundCount >= 2 && SoundManager.isOnSound == true)
        {
            this.endAudio.Play();
        }
    }
}
