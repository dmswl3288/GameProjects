﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TitleCollision : MonoBehaviour {

    public GUISkin mySkin;
    static public bool _displayTitle = false;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "LastCube") // ?큐브 마지막에 닿으면 
        {
            // Display Title Name 
            _displayTitle = true;
        }
    }

    private void OnGUI()
    {
        GUI.skin = mySkin;

        int sw = Screen.width;
        int sh = Screen.height;

        if (_displayTitle)
        {
            GUI.Label(new Rect(0, sh / 6, sw, sh / 4), "TOP BLOCK", "Title");
        }
    }
}
