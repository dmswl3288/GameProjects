﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TotalScoreCtl : MonoBehaviour {

    public GUISkin mySkin;
    int _bestScore = 0;

    // Use this for initialization
    void Start () {

        //마지막 씬에 최고점 불러오기
        LoadBestScore();

	}
	
	// Update is called once per frame
	void Update () {
		
	}

    // 최고점수 불러오는 함수
    void LoadBestScore()
    {
        _bestScore = PlayerPrefs.GetInt("Best Score", 0);
    }

    private void OnGUI()
    {
        GUI.skin = mySkin;

        int sw = Screen.width;
        int sh = Screen.height;

        // 현재 점수가 최고점보다 높다면
        if(Camera_Move._totalScore > _bestScore)
        {
            // 최고점수에 저장
            _bestScore = Camera_Move._totalScore;
            // 로컬에 최고 점수 저장  key값, 점수
            PlayerPrefs.SetInt("Best Score", _bestScore);
        }

        GUI.Label(new Rect(0, sh / 5, sw, sh / 4), "BEST SCORE\n" + _bestScore, "BestScore");
       
    }
}
