﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class isCollision : MonoBehaviour {

    // Use this for initialization
    void Start () {

    }

    // Update is called once per frame
    void Update () {
	
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Ground")  // 첫 땅에 닿을때
        {
            Destroy(GetComponent<Cube_Move>());
            Destroy(GetComponent<isCollision>());
            Camera_Move.CameraMoveSwitch = true;
        }
        

        if(collision.gameObject.tag == "Cube")  // 다음 큐브에 닿을때
        {
            Destroy(GetComponent<Cube_Move>());
            Destroy(GetComponent<isCollision>());
            Camera_Move.CameraMoveSwitch = true;

        }
    }
}
